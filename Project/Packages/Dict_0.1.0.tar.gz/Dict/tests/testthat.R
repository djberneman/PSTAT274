library(testthat)
library(Dict)

test_check("Dict")
