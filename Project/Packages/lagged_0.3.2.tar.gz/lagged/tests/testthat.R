library("testthat")
library("lagged")

options(useFancyQuotes = FALSE)

test_check("lagged")
