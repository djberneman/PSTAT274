#ifndef EM_H
#define EM_H

arma::vec getDelta(const arma::mat& gamma, const int& m);

#endif
