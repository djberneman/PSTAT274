".onLoad" <-
function(lib, pkg) library.dynam("ltsa", pkg, lib)

